# MTH686 Project

### The Three Candidate Models

1. **Model 1: Non-linear Exponential (Bi-exponential)**
   ```
   y(t) = α₀ + α₁·exp(β₁·t) + α₂·exp(β₂·t) + ε(t)
   ```
   - **Parameters**: 5 (α₀, α₁, β₁, α₂, β₂)

2. **Model 2: Non-linear Ratio (Rational Function)**
   ```
   y(t) = (α₀ + α₁·t) / (β₀ + β₁·t) + ε(t)
   ```
   - **Parameters**: 4 (α₀, α₁, β₀, β₁)

3. **Model 3: 4th-degree Polynomial**
   ```
   y(t) = β₀ + β₁·t + β₂·t² + β₃·t³ + β₄·t⁴ + ε(t)
   ```
   - **Parameters**: 5 (β₀, β₁, β₂, β₃, β₄)

## Getting Started

### Prerequisites

- Python 3.7 or higher
- Jupyter Notebook or JupyterLab (or VS Code with Jupyter extension)

### Installation

1. **Clone or download the project**
   ```bash
   cd MTH686
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

   Key packages include:
   - `numpy` - Numerical computing
   - `pandas` - Data manipulation
   - `scipy` - Scientific computing and optimization
   - `statsmodels` - Statistical models
   - `matplotlib` - Visualization

## Project Structure

```
MTH686/
├── OnA-all6.ipynb                      # Main analysis notebook
├── initial_guess_estimator.ipynb       # Initial guess determination
├── analysis.ipynb                      # Basic pre analysis
├── set-76.dat                          # Dataset
├── requirements.txt                    # Python dependencies
├── README.md                           # This file
└── utils/                             # Helper modules
    ├── data_loader.py                 # Data loading and normalization
    ├── models.py                      # Model definitions
    ├── gauss_newton.py                # Custom Gauss-Newton optimizer
    ├── gradient_descent.py            # Gradient descent optimizer
    └── initial_guesses.json           # Saved initial parameter guesses
```

## Mathematical Details

### Variable Projection Method

For models linear in some parameters (α) and non-linear in others (β):

1. **Projection**: For fixed β, find optimal α:
   ```
   α̂(β) = (X(β)^T * X(β))^-1 * X(β)^T * y
   ```

2. **Reduced Problem**: Minimize over β only:
   ```
   min RSS(β) = ||y - X(β)α̂(β)||²
   ```

3. **Benefits**:
   - Reduces dimensionality of optimization
   - Improves numerical stability
   - Faster convergence

### Akaike Information Criterion (AIC)

```
AIC = n·ln(RSS/n) + 2k
```

Where:
- n = number of observations
- RSS = residual sum of squares
- k = number of parameters

Lower AIC indicates better model (balances fit quality and complexity).

## Code Quality Features

- **Modular Design**: Reusable functions in `utils/` directory
- **Comprehensive Docstrings**: Every function fully documented
- **Type Hints**: Clear parameter and return types
- **Error Handling**: Robust numerical safeguards
- **Reproducibility**: Saved initial guesses ensure consistent results


~ Manas Jain Kuniya (Roll Number: 230626)
