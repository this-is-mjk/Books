"""
Statistical Model Definitions

This module defines the three candidate models for fitting the dataset:
1. Model 1: Non-linear Exponential (sum of two exponentials)
2. Model 2: Non-linear Ratio (rational function)
3. Model 3: 4th-degree Polynomial

Each model has distinct mathematical properties and is suitable for different
types of data patterns. Model selection is performed using AIC.

Functions
---------
model1 : Non-linear exponential model with two exponential terms
model2 : Non-linear ratio model (rational function)
model3_fit : Fit a 4th-degree polynomial using OLS
"""

import numpy as np
import statsmodels.api as sm

def model1(t, alpha0, alpha1, beta1, alpha2, beta2):
    """
    Model 1: Non-linear Exponential (Bi-exponential).
    
    This model describes a process as the sum of a constant and two exponential
    functions, commonly used for modeling decay processes, growth curves, or
    multi-component systems:
    
        y(t) = α₀ + α₁·exp(β₁·t) + α₂·exp(β₂·t) + ε(t)
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    alpha0 : float
        Constant offset (α₀), represents the baseline or asymptotic value.
    alpha1 : float
        Amplitude of the first exponential term (α₁).
    beta1 : float
        Rate parameter for the first exponential (β₁).
        Negative values indicate decay, positive indicate growth.
    alpha2 : float
        Amplitude of the second exponential term (α₂).
    beta2 : float
        Rate parameter for the second exponential (β₂).
        Negative values indicate decay, positive indicate growth.
    
    Returns
    -------
    numpy.ndarray
        Predicted values y(t), shape (n,).
    
    Notes
    -----
    - This model is linear in [α₀, α₁, α₂] but non-linear in [β₁, β₂].
    - Suitable for Variable Projection (VarPro) optimization.
    - Common applications: pharmacokinetics, reaction kinetics, signal processing.
    
    Examples
    --------
    >>> t = np.array([0, 1, 2, 3, 4])
    >>> y = model1(t, alpha0=2.0, alpha1=1.0, beta1=-0.5, alpha2=0.5, beta2=-0.1)
    """
    return alpha0 + alpha1 * np.exp(beta1 * t) + alpha2 * np.exp(beta2 * t)

def model2(t, alpha0, alpha1, beta0, beta1):
    """
    Model 2: Non-linear Ratio (Rational Function).
    
    This model describes a process as a ratio of two linear functions, commonly
    used for modeling saturation effects, Michaelis-Menten kinetics, or
    systems approaching an asymptote:
    
        y(t) = (α₀ + α₁·t) / (β₀ + β₁·t) + ε(t)
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    alpha0 : float
        Constant term in numerator (α₀).
    alpha1 : float
        Linear coefficient in numerator (α₁).
    beta0 : float
        Constant term in denominator (β₀).
    beta1 : float
        Linear coefficient in denominator (β₁).
    
    Returns
    -------
    numpy.ndarray
        Predicted values y(t), shape (n,).
    
    Notes
    -----
    - As t → ∞, y(t) → α₁/β₁ (horizontal asymptote).
    - At t = 0, y(0) = α₀/β₀ (initial value).
    - This model is linear in [α₀, α₁] but non-linear in [β₀, β₁].
    - Can be optimized using gradient descent or Variable Projection.
    - Common applications: enzyme kinetics, population dynamics, dose-response curves.
    
    Examples
    --------
    >>> t = np.array([0, 1, 2, 3, 4])
    >>> y = model2(t, alpha0=1.0, alpha1=2.0, beta0=1.0, beta1=1.0)
    """
    return (alpha0 + alpha1 * t) / (beta0 + beta1 * t)

def model3_fit(x, y):
    """
    Model 3: 4th-degree Polynomial using Ordinary Least Squares.
    
    Fits a polynomial model of degree 4 to the data using linear regression.
    This is a fully linear model in all parameters:
    
        y(t) = β₀ + β₁·t + β₂·t² + β₃·t³ + β₄·t⁴ + ε(t)
    
    Parameters
    ----------
    x : array_like
        The independent variable (time), shape (n,).
    y : array_like
        The dependent variable (observations), shape (n,).
    
    Returns
    -------
    statsmodels.regression.linear_model.RegressionResultsWrapper
        Fitted model object containing:
        - params: Estimated coefficients [β₀, β₁, β₂, β₃, β₄]
        - ssr: Sum of squared residuals
        - conf_int(): Method to compute confidence intervals
        - And other standard OLS diagnostics
    
    Notes
    -----
    - This is a standard linear regression problem, no iterations required.
    - Can capture complex non-linear patterns through polynomial terms.
    - Risk of overfitting with high-degree polynomials.
    - Polynomial regression can be sensitive to data scaling.
    - The model includes 5 parameters (k=5) for AIC calculation.
    
    Examples
    --------
    >>> x = np.array([0, 1, 2, 3, 4])
    >>> y = np.array([1.0, 1.5, 2.2, 3.1, 4.5])
    >>> model = model3_fit(x, y)
    >>> print(model.params)  # Coefficients [β₀, β₁, β₂, β₃, β₄]
    >>> predictions = model.predict(sm.add_constant(x))
    """
    X = sm.add_constant(x)
    X['x2'] = x**2
    X['x3'] = x**3
    X['x4'] = x**4
    model = sm.OLS(y, X).fit()
    return model
