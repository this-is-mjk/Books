"""
Gauss-Newton Optimizer

This module implements a custom non-linear least squares solver using the
Gauss-Newton algorithm combined with the Variable Projection method. It is
specifically designed for models that are linear in some parameters (alphas)
and non-linear in others (betas), such as exponential models.

The Variable Projection method reduces the dimensionality of the optimization
problem by analytically solving for the linear parameters at each iteration,
only optimizing over the non-linear parameters.

Functions
---------
X_mat : Build the design matrix for the linear parameters
solve_alpha : Solve for optimal linear parameters given non-linear parameters
gauss_newton_beta : Main optimizer using Gauss-Newton with VarPro
calculate_full_covariance : Calculate covariance matrix for all parameters
"""

import numpy as np
from numpy.linalg import norm, solve, pinv, LinAlgError

# ==============================================================================
# === HELPER FUNCTIONS ===
# ==============================================================================

def X_mat(t, betas):
    """
    Build the design matrix for Model 1 (Non-linear Exponential).
    
    Constructs the design matrix X(β) = [1, exp(β₁·t), exp(β₂·t)] for the
    linear portion of Model 1. This matrix is used to solve for the linear
    parameters (alphas) via least squares.
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    betas : array_like
        The non-linear parameters [β₁, β₂], shape (2,).
    
    Returns
    -------
    numpy.ndarray
        The design matrix with shape (n, 3), where each row corresponds to
        [1, exp(β₁·tᵢ), exp(β₂·tᵢ)].
    
    Notes
    -----
    To prevent numerical overflow, exponents are clipped to the range
    [-700, 700] before applying the exponential function.
    """
    betas = np.atleast_1d(betas)
    
    # np.log(np.finfo(float).max) is ~709.7. We clip to avoid overflow.
    max_exp = 700.0 
    
    cols = [np.ones_like(t)]
    for b in betas:
        # Clip the argument *before* passing to exp()
        exponent = np.clip(b * t, -max_exp, max_exp)
        cols.append(np.exp(exponent))
        
    return np.column_stack(cols)

def solve_alpha(t, Y, betas):
    """
    Solve for optimal linear parameters given non-linear parameters.
    
    For a given set of non-linear parameters (betas), this function solves
    for the optimal linear parameters (alphas) using ordinary least squares:
    α̂(β) = (X(β)ᵀ X(β))⁻¹ X(β)ᵀ Y
    
    This is the core of the Variable Projection method, where the linear
    parameters are "projected out" of the optimization problem.
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    Y : array_like
        The dependent variable (observations), shape (n,).
    betas : array_like
        The non-linear parameters [β₁, β₂], shape (2,).
    
    Returns
    -------
    numpy.ndarray
        The optimal linear parameters [α₀, α₁, α₂], shape (3,).
    
    Notes
    -----
    Uses `np.linalg.lstsq` for numerical stability, which is equivalent to
    solving the normal equations but more robust.
    """
    X = X_mat(t, betas)
    # Using lstsq for stability, equivalent to (XᵀX)⁻¹XᵀY
    alpha, *_ = np.linalg.lstsq(X, Y, rcond=None)
    return alpha

# ==============================================================================
# === MAIN OPTIMIZER ===
# ==============================================================================

def gauss_newton_beta(t, Y, b0, solve_alpha_func, X_mat_func,
                      max_iter=100, tol=1e-8, eps_jac=1e-6,
                      verbose=True):
    """
    Gauss-Newton optimizer with Variable Projection and backtracking line search.
    
    This function implements a robust Gauss-Newton method for non-linear least
    squares problems where the model is linear in some parameters and non-linear
    in others. It uses the Variable Projection (VarPro) technique to reduce the
    dimensionality of the optimization problem.
    
    The algorithm iteratively:
    1. Computes the Jacobian of residuals w.r.t. non-linear parameters (betas)
    2. Solves the Gauss-Newton system for a parameter update
    3. Uses backtracking line search to ensure RSS decreases
    4. Checks convergence based on step size
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    Y : array_like
        The dependent variable (observations), shape (n,).
    b0 : array_like
        Initial guess for non-linear parameters [β₁, β₂], shape (2,).
    solve_alpha_func : callable
        Function to solve for linear parameters given betas.
        Signature: solve_alpha_func(t, Y, betas) -> alphas
    X_mat_func : callable
        Function to build the design matrix given betas.
        Signature: X_mat_func(t, betas) -> X
    max_iter : int, optional
        Maximum number of iterations, default 100.
    tol : float, optional
        Convergence tolerance for step size, default 1e-8.
    eps_jac : float, optional
        Step size for finite difference Jacobian calculation, default 1e-6.
    verbose : bool, optional
        If True, print iteration progress, default True.
    
    Returns
    -------
    b : numpy.ndarray
        Optimized non-linear parameters [β₁, β₂], shape (2,).
    alpha : numpy.ndarray
        Optimized linear parameters [α₀, α₁, α₂], shape (3,).
    res : numpy.ndarray
        Final residuals, shape (n,).
    rss : float
        Final residual sum of squares.
    
    Notes
    -----
    - Uses central finite differences for Jacobian calculation.
    - Implements backtracking line search with up to 10 step reductions.
    - Falls back to pseudo-inverse if the Hessian approximation is singular.
    - Returns last valid parameters if optimization fails.
    
    Examples
    --------
    >>> t = np.array([0, 1, 2, 3, 4])
    >>> Y = np.array([1.5, 2.1, 2.3, 2.4, 2.5])
    >>> b0 = [-0.5, -0.1]
    >>> b_opt, alpha_opt, res, rss = gauss_newton_beta(
    ...     t, Y, b0, solve_alpha, X_mat, verbose=False
    ... )
    """
    # --- Initialization ---
    b = np.asarray(b0, dtype=float).copy()
    n = len(Y)
    try:
        alpha = solve_alpha_func(t, Y, b)
        X = X_mat_func(t, b)
        res = Y - X @ alpha
        rss = np.sum(res**2)
    except (LinAlgError, OverflowError) as e:
        print(f"Error during initialization with b0={b}: {e}")
        print("Your initial guess is likely unstable.")
        return None, None, None, np.inf

    if verbose:
        print(f"Initial RSS = {rss:.6g}, initial betas = {b}")

    # --- Iteration loop ---
    for k in range(max_iter):
        # --- Numerical Jacobian wrt betas (central finite differences) ---
        J = np.zeros((n, len(b)))
        for j in range(len(b)):
            h = eps_jac * max(1.0, abs(b[j]))
            b_plus = b.copy(); b_plus[j] += h
            b_minus = b.copy(); b_minus[j] -= h

            try:
                a_plus = solve_alpha_func(t, Y, b_plus)
                r_plus = Y - X_mat_func(t, b_plus) @ a_plus
                
                a_minus = solve_alpha_func(t, Y, b_minus)
                r_minus = Y - X_mat_func(t, b_minus) @ a_minus
            except (LinAlgError, OverflowError):
                print(f"Warning: LinAlgError during Jacobian calculation at iter {k}.")
                # Use a very large number to make this step fail
                J[:, j] = np.inf 
                break # Stop calculating Jacobian, this iter will fail/backtrack
            
            J[:, j] = (r_plus - r_minus) / (2 * h)

        # --- Gauss-Newton update (Δb = -(JᵀJ)⁻¹ Jᵀr) ---
        JTJ = J.T @ J
        g = J.T @ res
        try:
            delta = -solve(JTJ, g)
        except LinAlgError:
            try:
                delta = -pinv(JTJ) @ g # Fallback to pseudo-inverse
            except LinAlgError:
                print(f"CRITICAL: SVD in pinv failed at iter {k}. Stopping.")
                return b, alpha, res, rss # Return last good params

        # === ROBUST BACKTRACKING LINE SEARCH ===
        step = 1.0
        step_accepted = False
        for _ in range(10): # Try up to 10 step-size cuts
            try:
                b_new = b + step * delta
                alpha_new = solve_alpha_func(t, Y, b_new)
                res_new = Y - X_mat_func(t, b_new) @ alpha_new
                rss_new = np.sum(res_new**2)

                # Check for NaN/Inf AND if RSS increased
                if not np.isfinite(rss_new) or rss_new > rss:
                    # This step is bad (unstable or worse), try a smaller step
                    step *= 0.5
                    continue
                
                # --- Accept new step ---
                b, alpha, res, rss = b_new, alpha_new, res_new, rss_new
                step_accepted = True
                if verbose and step < 1.0:
                    print(f"  Backtracked to step {step:.3f}, RSS = {rss:.6g}")
                break # Exit line search loop
            
            except (LinAlgError, OverflowError, ValueError):
                # An error occurred (e.g., lstsq failed), try a smaller step
                step *= 0.5
        
        if not step_accepted:
            print(f"Warning: Backtracking failed to find a better step at iter {k}. Stopping.")
            break # Exit main iteration loop
        # === END OF BACKTRACKING ===
        
        if verbose:
            print(f"Iter {k+1:02d}: β = {b}, RSS = {rss:.6g}")

        # --- Check for convergence ---
        step_norm = norm(step * delta)
        if step_norm < tol * (1 + norm(b)):
            print(f"Converged (small step) at iteration {k+1}")
            break
            
    else:
        print("Warning: Maximum number of iterations reached without convergence.")

    return b, alpha, res, rss

# ==============================================================================
# === COVARIANCE CALCULATION ===
# ==============================================================================

def calculate_full_covariance(alpha_hat, b_hat, t, n, sigma2_hat):
    """
    Calculate the full covariance matrix for all model parameters.
    
    Computes the 5×5 covariance matrix for all parameters [α₀, α₁, α₂, β₁, β₂]
    based on the observed Fisher Information matrix. This matrix quantifies the
    uncertainty in the parameter estimates and is used for confidence intervals
    and hypothesis testing.
    
    Parameters
    ----------
    alpha_hat : array_like
        Estimated linear parameters [α₀, α₁, α₂], shape (3,).
    b_hat : array_like
        Estimated non-linear parameters [β₁, β₂], shape (2,).
    t : array_like
        The independent variable (time), shape (n,).
    n : int
        Number of observations.
    sigma2_hat : float
        Estimated error variance (σ²).
    
    Returns
    -------
    cov_theta : numpy.ndarray
        Covariance matrix for all parameters, shape (5, 5).
        Parameters ordered as [α₀, α₁, α₂, β₁, β₂].
    se_theta : numpy.ndarray
        Standard errors for all parameters, shape (5,).
        Parameters ordered as [α₀, α₁, α₂, β₁, β₂].
    
    Notes
    -----
    The covariance matrix is computed as:
    Cov(θ) = σ² · (JᵀJ)⁻¹
    
    where J is the Jacobian matrix of the model with respect to all parameters.
    If JᵀJ is singular, the pseudo-inverse is used instead.
    
    Examples
    --------
    >>> alpha_hat = np.array([1.5, 0.5, -0.3])
    >>> b_hat = np.array([-0.5, -0.1])
    >>> t = np.linspace(0, 5, 50)
    >>> n = len(t)
    >>> sigma2_hat = 0.01
    >>> cov, se = calculate_full_covariance(alpha_hat, b_hat, t, n, sigma2_hat)
    """
    alpha0, alpha1, alpha2 = alpha_hat
    b1, b2 = b_hat
    
    # Jacobian of predicted y w.r.t parameters [α0, α1, α2, β1, β2]
    col_alpha0 = np.ones_like(t)                      # ∂y/∂α0
    col_alpha1 = np.exp(b1 * t)                       # ∂y/∂α1
    col_alpha2 = np.exp(b2 * t)                       # ∂y/∂α2
    col_beta1  = alpha1 * t * np.exp(b1 * t)          # ∂y/∂β1
    col_beta2  = alpha2 * t * np.exp(b2 * t)          # ∂y/∂β2
    
    # Combine into Jacobian matrix (n × 5)
    J = np.column_stack([col_alpha0, col_alpha1, col_alpha2, col_beta1, col_beta2])
    
    # Fisher Information (observed) and covariance
    JTJ = J.T @ J
    
    try:
        inv_JTJ = solve(JTJ, np.eye(JTJ.shape[0]))
    except LinAlgError:
        print("Warning: singular matrix (JᵀJ), using pseudo-inverse for covariance.")
        inv_JTJ = pinv(JTJ)
        
    cov_theta = sigma2_hat * inv_JTJ
    se_theta = np.sqrt(np.diag(cov_theta))
    
    # Returns covariance and SEs in the order [a0, a1, a2, b1, b2]
    return cov_theta, se_theta