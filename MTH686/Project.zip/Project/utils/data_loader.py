"""
Data Loading and Preprocessing Module

This module provides functionality to load and preprocess the dataset for
statistical modeling. It handles reading whitespace-separated data files
and optionally normalizing (standardizing) the independent variable.

Functions
---------
load_data : Load dataset from file with optional normalization
"""

import pandas as pd
from io import StringIO

def load_data(file_path='set-76.dat', normalize=False):
    """
    Load dataset from a whitespace-separated file.
    
    Reads a data file containing two columns (x and y) separated by whitespace
    and returns it as a pandas DataFrame. Optionally normalizes the x variable
    to zero mean and unit standard deviation for improved numerical stability
    in non-linear optimization.
    
    Parameters
    ----------
    file_path : str, optional
        Path to the data file, default 'set-76.dat'.
        The file should contain two columns: independent variable (x) and
        dependent variable (y), separated by whitespace.
    normalize : bool, optional
        If True, standardize the x variable: x_scaled = (x - mean) / std.
        Adds a new 'x_scaled' column to the DataFrame and returns the
        normalization parameters (mean and std). Default False.
    
    Returns
    -------
    df : pandas.DataFrame
        DataFrame with columns ['x', 'y'] and optionally ['x_scaled'].
    x_mean : float or None
        Mean of x if normalize=True, otherwise None.
    x_std : float or None
        Standard deviation of x if normalize=True, otherwise None.
    
    Notes
    -----
    Normalization is recommended for non-linear optimization to:
    - Improve numerical stability
    - Balance parameter scales
    - Speed up convergence
    
    Remember to transform betas back to original scale: β_orig = β_scaled / x_std
    
    Examples
    --------
    >>> # Load without normalization
    >>> df, _, _ = load_data('set-76.dat', normalize=False)
    >>> 
    >>> # Load with normalization
    >>> df, x_mean, x_std = load_data('set-76.dat', normalize=True)
    >>> print(df.columns)
    Index(['x', 'y', 'x_scaled'], dtype='object')
    """
    with open(file_path, 'r', encoding="utf-8") as f:
        try:
            df = pd.read_csv(StringIO(f.read()), sep='\\s+', header=None)
            df.columns = ['x', 'y']
            print("Data initialized into df")

            if normalize:
                x_mean = df['x'].mean()
                x_std = df['x'].std()
                if x_std == 0: x_std = 1.0 # Avoid division by zero
                df['x_scaled'] = (df['x'] - x_mean) / x_std
                print("Data has been normalized.")
                return df, x_mean, x_std
            else:
                return df, None, None

        except FileNotFoundError:
            print("File not found.")
            return None, None, None
        except Exception as e:
            print(f"An error occurred: {e}")
            return None, None, None
