"""
Gradient Descent Optimizer for Model 2 (Non-linear Ratio)

This module implements a gradient descent optimizer specifically designed for
fitting Model 2, which has a rational (ratio) functional form:
    y(t) = (α₀ + α₁·t) / (β₀ + β₁·t)

The optimizer uses analytical gradients and a fixed learning rate to iteratively
minimize the residual sum of squares.

Functions
---------
model2_pred : Compute predictions for Model 2
model2_gradients : Compute gradients of RSS w.r.t. all parameters
fit_gradient_descent : Main gradient descent optimization function
"""

import numpy as np

def model2_pred(t, a0, a1, b0, b1):
    """
    Compute predictions for Model 2 (Non-linear Ratio).
    
    Evaluates the rational function:
        y(t) = (α₀ + α₁·t) / (β₀ + β₁·t)
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    a0 : float
        Parameter α₀ (numerator constant).
    a1 : float
        Parameter α₁ (numerator slope).
    b0 : float
        Parameter β₀ (denominator constant).
    b1 : float
        Parameter β₁ (denominator slope).
    
    Returns
    -------
    numpy.ndarray
        Predicted values, shape (n,).
    
    Notes
    -----
    A safeguard is applied to prevent division by zero: denominators with
    absolute value less than 1e-12 are replaced with 1e-12.
    """
    denominator = b0 + b1 * t
    # Add safeguard for potential division by zero
    denominator[np.abs(denominator) < 1e-12] = 1e-12
    return (a0 + a1 * t) / denominator

def model2_gradients(t_values, y_values, a0, a1, b0, b1):
    """
    Compute gradients of RSS with respect to all parameters for Model 2.
    
    Calculates the partial derivatives of the residual sum of squares (RSS)
    with respect to each of the four parameters [α₀, α₁, β₀, β₁].
    
    The gradients are derived from the model:
        y(t) = (α₀ + α₁·t) / (β₀ + β₁·t)
    
    and the RSS function:
        RSS = Σ (ŷᵢ - yᵢ)²
    
    Parameters
    ----------
    t_values : array_like
        The independent variable (time), shape (n,).
    y_values : array_like
        The observed dependent variable, shape (n,).
    a0 : float
        Current value of parameter α₀.
    a1 : float
        Current value of parameter α₁.
    b0 : float
        Current value of parameter β₀.
    b1 : float
        Current value of parameter β₁.
    
    Returns
    -------
    tuple of float
        (gradient_a0, gradient_a1, gradient_b0, gradient_b1)
        The gradient of RSS w.r.t. each parameter.
    
    Notes
    -----
    A safeguard is applied to prevent division by zero in the denominator.
    """
    # --- Predicted values ---
    predictions = model2_pred(t_values, a0, a1, b0, b1)
    
    # --- Compute residuals ---
    errors = predictions - y_values
    
    # --- Initialize gradients ---
    gradient_a0 = 0.0
    gradient_a1 = 0.0
    gradient_b0 = 0.0
    gradient_b1 = 0.0
    
    # --- Compute gradients via summation ---
    for i in range(len(t_values)):
        t_i = t_values[i]
        error_i = errors[i]
        numerator = (a0 + a1 * t_i)
        denominator = (b0 + b1 * t_i)
        # Add safeguard
        if np.abs(denominator) < 1e-12:
            denominator = 1e-12
            
        common_term = 2 * error_i / denominator
        
        gradient_a0 += common_term
        gradient_a1 += common_term * t_i
        gradient_b0 -= common_term * numerator / denominator
        gradient_b1 -= common_term * t_i * numerator / denominator
    
    return gradient_a0, gradient_a1, gradient_b0, gradient_b1

def fit_gradient_descent(t, Y, p0, lr, num_iters, verbose=False):
    """
    Fit Model 2 using gradient descent optimization.
    
    Minimizes the residual sum of squares (RSS) for Model 2 using gradient
    descent with a fixed learning rate. The algorithm iteratively updates
    parameters in the direction opposite to the gradient.
    
    Parameters
    ----------
    t : array_like
        The independent variable (time), shape (n,).
    Y : array_like
        The dependent variable (observations), shape (n,).
    p0 : array_like
        Initial parameter guesses [α₀, α₁, β₀, β₁], shape (4,).
    lr : float
        Learning rate (step size) for gradient descent.
    num_iters : int
        Number of iterations to perform.
    verbose : bool, optional
        If True, print RSS every 1000 iterations, default False.
    
    Returns
    -------
    final_params : numpy.ndarray
        Optimized parameters [α₀, α₁, β₀, β₁], shape (4,).
    final_rss : float
        Final residual sum of squares.
    
    Notes
    -----
    - Uses a fixed learning rate without adaptive step sizing.
    - The learning rate should be tuned based on the problem scale.
    - Typical values: lr ~ 1e-5 to 1e-4 for normalized data.
    
    Examples
    --------
    >>> t = np.array([0, 1, 2, 3, 4])
    >>> Y = np.array([1.0, 1.5, 1.8, 2.0, 2.1])
    >>> p0 = [1.0, 1.0, 1.0, 1.0]
    >>> params, rss = fit_gradient_descent(t, Y, p0, lr=1e-5, num_iters=10000)
    """
    # --- Initialize Parameters ---
    a0, a1, b0, b1 = p0
    
    loss_history = []
    
    for i in range(num_iters):
        ga0, ga1, gb0, gb1 = model2_gradients(t, Y, a0, a1, b0, b1)
        
        # --- Update parameters ---
        a0 = a0 - ga0 * lr
        a1 = a1 - ga1 * lr
        b0 = b0 - gb0 * lr
        b1 = b1 - gb1 * lr
        
        if i % 1000 == 0 and verbose:
            predictions = model2_pred(t, a0, a1, b0, b1)
            errors = Y - predictions
            rss = np.sum(errors**2)
            loss_history.append(rss)
            print(f"Iter {i}: RSS = {rss:.6f}")
    
    # --- Final calculations ---
    final_params = np.array([a0, a1, b0, b1])
    final_predictions = model2_pred(t, a0, a1, b0, b1)
    final_errors = Y - final_predictions
    final_rss = np.sum(final_errors**2)
    
    return final_params, final_rss